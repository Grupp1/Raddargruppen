package raddar.enums;

public enum SituationPriority {
	
	HIGH,
	NORMAL,
	LOW;

}
