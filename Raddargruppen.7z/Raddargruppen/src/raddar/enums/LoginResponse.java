package raddar.enums;

public enum LoginResponse {

	ACCEPTED,
	NO_SUCH_USER,
	WRONG_PASSWORD,
	NO_CONNECTION,
	ERROR;
	
}
