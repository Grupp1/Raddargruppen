package tddd36.server;

public class LoginManager {

	public boolean login(String user, String Password){
		try{
			
			
			
			
		}catch(Exception e){
			
		}
		return true;
	}
}
