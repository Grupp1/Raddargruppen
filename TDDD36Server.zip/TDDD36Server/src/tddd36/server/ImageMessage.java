package tddd36.server;

import java.io.File;

public class ImageMessage extends Message {
	
	// H�r kommer bilden sparas efter att man l�st in den fr�n
	// telefonens minne (d�r den lagras efter att man tagit ett kort t ex)
	
	//private Bitmap imgBitmap;
	
	public ImageMessage() {
		
	}
	
	
	public void setImage(File path) {
		
	}


	@Override
	public String getFormattedMessage() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
