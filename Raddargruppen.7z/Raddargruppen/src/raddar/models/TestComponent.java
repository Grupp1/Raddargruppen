package raddar.models;

public class TestComponent {
	
	public boolean lol(){
		return false;
	}

	public int raddd(){
		return 0;
	}
	public static void main(String[] args) {
		System.out.println("HEEEJ DANNE!!!");
	}

	
	public void hejdanne(){
		// jkashdjklashdjkahsdj
	}
	
}
