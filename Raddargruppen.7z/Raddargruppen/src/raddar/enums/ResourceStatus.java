package raddar.enums;

public enum ResourceStatus {

	BUSY,
	FREE;
	
}
